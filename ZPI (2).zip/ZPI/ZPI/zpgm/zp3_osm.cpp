#include <fstream>
#include <sstream>
#include <cmath>
#include <array>
#include <iostream>
#include <tuple>
#include <chrono>
#include <numeric>
#include <vector>
#include <random>
#include <limits>
#include <algorithm>
#include "/home/wrj/project/ZM/pgm/pgm_index.hpp"
//#include "../pgm/pgm_index_variants.hpp"

//template<size_t Dim=2, size_t Epsilon=64>
using Index = pgm::PGMIndex<u_int64_t,64>;


struct Point {
    float x, y;  // 改为64位整型
    u_int32_t x_i, y_i;
    long long code;
     // 添加默认构造函数
     Point() = default;

     // 带参构造函数方便初始化
     Point(float _x, float _y) : x(_x), y(_y) {}
};

struct xyPoint {
    float x, y;
    xyPoint(float x_val = 0.0f, float y_val = 0.0f) : x(x_val), y(y_val) {}
};

// 将Region定义移至全局作用域
template <typename k = u_int64_t>   
struct Region {
    std::vector<xyPoint> points;
    u_int32_t x1, y1, x2, y2;
    pgm::PGMIndex<k> model;
    std::vector<u_int64_t> codes;
};

// 定义一个段
typedef std::pair<int, int> Segment1;

// 定义一个序列
typedef std::vector<Segment1> Sequence;
Sequence S1,S2;

// uint64_t z_order_encode(int x, int y) {
//     uint64_t z = 0;
//     for (int i = 0; i < 32; ++i) {
//         z |= ((x & (1ULL << i)) << i);
//         z |= ((y & (1ULL << i)) << (i + 1));
//     }
//     return z;
// }

uint64_t z_order_encode(u_int32_t x, u_int32_t y) {
    uint64_t z = 0;
    for (int i = 0; i < 32; ++i) {
        // [修改2] 修复位操作，确保类型转换正确
        z |= ((static_cast<uint64_t>(x & (1ULL << i))) << i);
        z |= ((static_cast<uint64_t>(y & (1ULL << i))) << (i + 1));
    }
    return z;
}

std::vector<Point> read_data_from_csv(const std::string& filename) {
    std::vector<Point> data;
    std::ifstream file(filename);
    std::string line;

    while (std::getline(file, line)) {
        std::stringstream ss(line);
        std::string value;
        std::vector<float> point;

        while (std::getline(ss, value, ',')) {
            point.push_back(std::stod(value));
        }

        if (point.size() == 2) {
            data.push_back({ point[0], point[1]});
        }
    }

    return data;
}


const size_t Dim = 2;
std::array<float, Dim> mins;
std::array<float, Dim> maxs;
std::array<float, Dim> widths;

void compute_grid_indices(std::vector<Point>& points) {
    mins.fill(std::numeric_limits<float>::max());
    maxs.fill(std::numeric_limits<float>::lowest());

    // 计算每个维度的最小和最大值
    for (size_t i = 0; i < Dim; ++i) {
        for (const auto& p : points) {
            float val = (i == 0) ? p.x : p.y;
            if (val < mins[i]) mins[i] = val;
            if (val > maxs[i]) maxs[i] = val;
        }
    }

    // 计算网格分辨率
    size_t resolution = static_cast<size_t>(std::pow(points.size(), 1.0 / Dim));
    resolution=8192;
    // 计算每个维度的宽度
    for (size_t i = 0; i < Dim; ++i) {
        double range = maxs[i] - mins[i];
        if (range == 0) {
            widths[i] = 0; // 所有点在该维度值相同
        } else {
            widths[i] = range / resolution;
        }
    }

    // 为每个点计算整数索引
    for (auto& p : points) {
        for (size_t i = 0; i < Dim; ++i) {
            float val = (i == 0) ? p.x : p.y;
            size_t index;
            if (widths[i] == 0) {
                index = 0;
            } else if (val <= mins[i]) {
                index = 0;
            } else if (val >= maxs[i]) {
                index = resolution - 1; // 防止越界
            } else {
                index = static_cast<size_t>((val - mins[i]) / widths[i]);
                // 确保由于浮点精度不会超过范围
                if (index >= resolution) index = resolution - 1;
            }
            if (i == 0) {
                p.x_i = index;
            } else {
                p.y_i = index;
            }
            
        }
        //std::cout<<"point:"<<p.x_i<<" "<<p.y_i <<"   "<<p.x<<":"<<p.y<<std::endl;
        // 生成Z-order编码
       p.code = z_order_encode(p.x_i, p.y_i);
    }
}




/* run this program using the console pauser or add your own getch, system("pause") or input loop */
void addSequence1(int mins,int maxs){
    // 如果序列为空，直接添加新段
    if (S1.empty()) {
        S1.push_back(std::make_pair(mins, maxs));
    } else {
        // 获取序列中的最后一个段
        Segment1 &lastSegment = S1.back();
 
        // 如果最后一个段和新段是连续的，合并它们
        if (lastSegment.second + 1 == mins) {
            lastSegment.second = maxs;
        } else {
            // 否则，直接添加新段
            S1.push_back(std::make_pair(mins, maxs));
        }
    }
   
}


void addSequence2(int mins,int maxs){
    // 如果序列为空，直接添加新段
    if (S2.empty()) {
        S2.push_back(std::make_pair(mins, maxs));
    } else {
        // 获取序列中的最后一个段
        Segment1 &lastSegment = S2.back();
 
        // 如果最后一个段和新段是连续的，合并它们
        if (lastSegment.second + 1 == mins) {
            lastSegment.second = maxs;
        } else {
            // 否则，直接添加新段
            S2.push_back(std::make_pair(mins, maxs));
        }
    }
    
   
}

int determineType(int x,int y,int p,int q,int N2){
   int mid=N2;
   if(x<mid){
       if(y<mid){//窗口起点在左下角，
           if(x+q<=mid){
               if(y+p<=mid){ //窗口终点在左下角 
                   return 7;
               }else{    //窗口终点在左上角 
                   return 3;
               }
           }else{ 
               if(y+p<=mid){ //窗口终点在右下角 
                   return 2;
               }else{    //窗口终点在右上角 
                   return 0;
               }
           }
       }else{//起点左上角 
           if(x+q<=mid){
               return 5;
           }else{
               return 1;
           }
       }
       
   }else{  
       if(y<mid){//起点在右下角 
           if(y+p<=mid){
               return 8;
           }else{
               return 4;
           }
       }else{  //起点在右上角 
           return 6;
       }        
   }
}
void QSplit(int T,int mino,int x,int y,int p,int q){
    int N2=T/2;
    int N4=N2*N2;
     if(T==p&&T==q&&T>=32){
        addSequence1(mino,mino+T*T-1);
    }
    else if(T<32){
        addSequence2(mino,mino+T*T-1);
       
    }else{
        int type=determineType(x,y,p,q,N2);
        switch(type){
            case 0:{
                QSplit(N2,mino,x,y,N2-y,N2-x);
                QSplit( N2, mino + N4 , 0, y, N2 - y, x + q - N2);
                QSplit( N2, mino + N4*2, x, 0, y + p - N2, N2 - x);
                QSplit( N2, mino + N4 *3, 0, 0, y + p-N2, x + q - N2);
                break;
            }
            case 1:{
                QSplit( N2, mino + N4*2, x, y - N2, p, N2 - x);
                QSplit( N2, mino + N4 * 3, 0, y - N2, p, x + q - N2);                
                break;
            }
            case 2:{
                QSplit( N2, mino, x, y, p, N2 - x);
                QSplit( N2, mino + N4, 0, y, p, x + q - N2);
                break;
            }
            case 3:{
                QSplit( N2, mino, x, y, N2 - y, q);
                QSplit( N2, mino + N4*2, x, 0, y + p - N2, q);
                break;
            } 
            case 4:{
                QSplit( N2, mino + N4, x - N2, y, N2 - y, q);
                QSplit( N2, mino + N4 * 3, x - N2, 0, y + p - N2, q);
                
                break;
            } 
            case 5:{
                QSplit( N2, mino + N4*2, x, y - N2, p, q);
                break;
            }
            case 6:{
                QSplit( N2, mino + N4 * 3, x - N2, y - N2, p, q);
                break;
            }
            case 7:{
                QSplit( N2, mino, x, y, p, q);
                break;
            }
            case 8:{
                QSplit( N2, mino+N4 , x - N2, y, p, q);
                break;
            }
        }
    }
}

template<typename K>
size_t exact_start_search(const pgm::PGMIndex<K>& index,
                          const std::vector<K>& data,
                          const K& key) {
    auto a = index.search(key);
    size_t lo = std::min<size_t>(a.lo, data.size());
    size_t hi = std::min<size_t>(a.hi, data.size());
    auto it = std::lower_bound(data.begin() + lo, data.begin() + hi, key);
    return static_cast<size_t>(it - data.begin());
}

// 返回 “第一个 > key 的位置”(end exclusive)
template<typename K>
size_t exact_last_search(const pgm::PGMIndex<K>& index,
                        const std::vector<K>& data,
                        const K& key) {
    auto a = index.search(key);
    size_t lo = std::min<size_t>(a.lo, data.size());
    size_t hi = std::min<size_t>(a.hi, data.size());
    auto it = std::upper_bound(data.begin() + lo, data.begin() + hi, key);
    return static_cast<size_t>(it - data.begin());
}


// 修改后的 range_query 函数以支持多个查询框
template<typename K>
std::vector<xyPoint> range_query(const std::vector<Point>& data,const std::vector<u_int64_t>& code,const pgm::PGMIndex<K>& model,
    const Point& query_min,
    const Point& query_max) 
    {

        std::vector<xyPoint> results;
        int x1=query_min.x_i;
        int x2=query_max.x_i;
        int y1=query_min.y_i;
        int y2=query_max.y_i;
        // std::cout<<"x-y: "<<overlap_x1<<" "<<overlap_y1<<" "<<overlap_x2<<" "<<overlap_y2<<std::endl;
        // const u_int32_t mask = ~0b11111; 
        // x1=x1&mask;
        // y1=y1&mask;
        // x2=(x2&mask)+32;
        // y2=(y2&mask)+32;
        // std::cout<<"x-y: "<<overlap_x1<<" "<<overlap_y1<<" "<<overlap_x2<<" "<<overlap_y2<<std::endl;
         //std::cout<<"code: "<<z_order_encode(x1,y1)<<" "<<z_order_encode(x2,y2) <<std::endl;
        S1.clear();
        S2.clear();
        QSplit(16384,0,x1,y1,y2-y1,x2-x1);
        for(int i=0;i<S1.size();i++){

            // 使用分段模型预测位置范围[3](@ref)
        
    
        // int pred_start = std::max<int>(0, static_cast<int>(predict(model, S[i].first)) - 128);
        // int pred_end = std::min<int>(region.points.size()-1, (int)predict(model, max_code) + 128);
        uint64_t min_code=S1[i].first;
        uint64_t max_code=S1[i].second;


        // int pred_start_min = std::max<int>(0, static_cast<int>(predict(model, min_code))-128);
        // int pred_start_max = std::min<int>(data.size()-1, (int)predict(model, min_code) +128);
        // int pred_end_min = std::max<int>(0, static_cast<int>(predict(model, max_code))-128);
        // int pred_end_max = std::min<int>(data.size()-1, (int)predict(model, max_code) +128);
    

        size_t pred_start = exact_start_search(model, code, min_code);
            size_t pred_end   = exact_last_search(model,  code, max_code);
            
            // 边界保护
            if (pred_start >= pred_end || pred_start >= code.size()) continue;
            pred_end = std::min(pred_end, code.size());
            
            for (size_t i = pred_start; i < pred_end; ++i) {
                xyPoint p;

                p.x = data[i].x;
                p.y=data[i].y;
                results.emplace_back(p);
                // if (p.x >= query_min.x && p.x <= query_max.x &&
                //     p.y >= query_min.y && p.y <= query_max.y) {
                //     results.emplace_back(p);
                // }
                
            }
        
    }
        for(int i=0;i<S2.size();i++){

                // 使用分段模型预测位置范围[3](@ref)
            
        
            // int pred_start = std::max<int>(0, static_cast<int>(predict(model, S[i].first)) - 128);
            // int pred_end = std::min<int>(region.points.size()-1, (int)predict(model, max_code) + 128);
            uint64_t min_code=S2[i].first;
            uint64_t max_code=S2[i].second;


            // int pred_start_min = std::max<int>(0, static_cast<int>(predict(model, min_code))-128);
            // int pred_start_max = std::min<int>(data.size()-1, (int)predict(model, min_code) +128);
            // int pred_end_min = std::max<int>(0, static_cast<int>(predict(model, max_code))-128);
            // int pred_end_max = std::min<int>(data.size()-1, (int)predict(model, max_code) +128);
        

            size_t pred_start = exact_start_search(model, code, min_code);
            size_t pred_end   = exact_last_search(model,  code, max_code);
            
            // 边界保护
            if (pred_start >= pred_end || pred_start >= code.size()) continue;
            pred_end = std::min(pred_end, code.size());
            
            for (size_t i = pred_start; i < pred_end; ++i) {
                xyPoint p;

                p.x = data[i].x;
                p.y=data[i].y;
                //results.emplace_back(p);
                if (p.x >= query_min.x && p.x <= query_max.x &&
                    p.y >= query_min.y && p.y <= query_max.y) {
                    results.emplace_back(p);
                }
                
            }
            
          
        }
        
        
        
    
         return results;
    }

           
            
  // 在main函数末尾添加内存分析
#include <cstddef>
void analyze_memory_usage(const std::vector<Point>& data, 
                          const std::vector<uint64_t>& code,
                          const Index& pgm_idx) {
    // 1. 原始数据
    size_t data_memory = data.size() * sizeof(xyPoint);
    
    // 2. Z-order编码数组
    size_t code_memory = code.capacity() * sizeof(uint64_t);
    
    // 3. PGM索引大小
    size_t pgm_memory = pgm_idx.size_in_bytes();
    
    
   
    size_t total_estimated = data_memory  + pgm_memory 
                           
                           + code_memory;
    
    std::cout << "\n总估计内存: " 
              << total_estimated  << " B" << std::endl;
}                




std::vector<xyPoint> read_csv(const std::string& filename) {
    std::vector<xyPoint> pts;
    std::ifstream f(filename);
    if (!f) { std::cerr << "❌ Open failed: " << filename << "\n"; return pts; }
    std::string line;
    while (std::getline(f, line)) {
        if (line.empty()) continue;
        std::stringstream ss(line);
        std::string x, y;
        if (std::getline(ss, x, ',') && std::getline(ss, y)) {
            try { pts.push_back(xyPoint(std::stod(x), std::stod(y))); } catch (...) {}
        }
    }
    f.close();
    return pts;
}

// ───── 2. 计算 min / max per dim ─────
// ───── 2. 计算 min / max per dim ─────
std::pair<xyPoint, xyPoint> compute_min_max(const std::vector<xyPoint>& pts) {
    xyPoint mins, maxs;
    mins.x = mins.y = std::numeric_limits<float>::max();
    maxs.x = maxs.y = std::numeric_limits<float>::lowest();
    
    for (const auto& p : pts) {
        mins.x = std::min(mins.x, p.x);
        mins.y = std::min(mins.y, p.y);
        maxs.x = std::max(maxs.x, p.x);
        maxs.y = std::max(maxs.y, p.y);
    }
    return {mins, maxs};
}

// ───── 3. 采样点（关键：种子=42，与原代码一致） ─────

std::vector<xyPoint> sample_points(const std::vector<xyPoint>& pts, size_t s) {
    std::mt19937 gen(42); // ← 必须是 42！
    std::uniform_int_distribution<size_t> dist(0, pts.size() - 1);
    std::vector<xyPoint> samples;
    samples.reserve(s);
    for (size_t i = 0; i < s; ++i) {
        samples.push_back(pts[dist(gen)]);
    }
    return samples;
}

// ───── 4. 核心：完全复现原 sample_range_queries 逻辑 ─────
std::vector<std::vector<std::pair<xyPoint, xyPoint>>> generate_identical_range_queries(
    const std::vector<xyPoint>& points,
    size_t s
) {
    const double selectivities[5] = {0.001, 0.01, 0.05, 0.1, 0.2};
    auto sampled_points = sample_points(points, s);
    auto [global_min, global_max] = compute_min_max(points);

    std::vector<std::vector<std::pair<xyPoint, xyPoint>>> result;
    result.reserve(5);

    for (int i = 0; i < 5; ++i) {
        std::vector<std::pair<xyPoint, xyPoint>> group;
        group.reserve(s);

        for (const auto& point : sampled_points) {
            xyPoint min_corner = point; // ← this is the key: use point as min
            xyPoint max_corner;

            // 计算x维度范围
            float range_x = global_max.x - global_min.x;
            float step_x = range_x * std::pow(selectivities[i], 1.0 / 2.0);
            max_corner.x = std::min(point.x + step_x, global_max.x);

            // 计算y维度范围
            float range_y = global_max.y - global_min.y;
            float step_y = range_y * std::pow(selectivities[i], 1.0 / 2.0);
            max_corner.y = std::min(point.y + step_y, global_max.y);

            // Ensure min <= max (though it should be by construction)
            xyPoint final_min, final_max;
            final_min.x = std::min(min_corner.x, max_corner.x);
            final_min.y = std::min(min_corner.y, max_corner.y);
            final_max.x = std::max(min_corner.x, max_corner.x);
            final_max.y = std::max(min_corner.y, max_corner.y);

            group.emplace_back(final_min, final_max);
        }
        result.push_back(std::move(group));
    }

    return result;
}


int main() {
    std::mt19937 gen(42);
    auto data = read_data_from_csv("/home/wrj/project/ZM/data/osm3.csv");
    
    //auto data = read_binary("/home/wrj/project/ZM/data/data1");
    std::cout << "Loaded " << data.size() << " points from CSV" << std::endl;
    auto start = std::chrono::steady_clock::now();
    compute_grid_indices(data);

    std::sort(data.begin(), data.end(),
          [](auto& a, auto& b){ return a.code < b.code; });

    std::vector<uint64_t> code;
    code.reserve(data.size());
    for (auto& p: data) code.push_back(p.code);
    Index pgm_idx(code.begin(), code.end());
    auto end = std::chrono::steady_clock::now();
    auto build_time = std::chrono::duration_cast<std::chrono::milliseconds>(end - start).count();
    std::cout<<"build time:"<<build_time<<std::endl;
    analyze_memory_usage(data, code, pgm_idx);
    // size_t cdf_size = 0;
    // for (size_t i=0; i<K_CLUSTERS; ++i) {
    //     cdf_size += regions[i].model.size_in_bytes();
    // }
    // std::cout<<"index size:"<<cdf_size+data.size()*sizeof(xyPoint)<<std::endl;
    // size_t cdf_size = 0;
    // for (size_t i=0; i<; ++i) {
    //     cdf_size += this->indexes[i]->size_in_bytes();
    // }

     // 定义多个查询框
   auto data1 = read_csv("/home/wrj/project/ZM/data/osm3.csv");
     auto queries = generate_identical_range_queries(data1, 1000);
    
    

    

    std::vector<int> results_list(5000);
    std::vector<int> results_time(5);
    int n = 0,t=0;
    for(auto& query:  queries){
  
        auto query_start = std::chrono::high_resolution_clock::now();
        for (auto& pair : query) {
            
            Point min_corner, max_corner;
            min_corner.x=pair.first.x;
            min_corner.y=pair.first.y;
            min_corner.x_i = static_cast<size_t>((pair.first.x - mins[0]) / widths[0]);
            min_corner.y_i = static_cast<size_t>((pair.first.y - mins[1]) / widths[1]);
            max_corner.x=pair.second.x;
            max_corner.y=pair.second.y;
            max_corner.x_i = static_cast<size_t>((pair.second.x - mins[0]) / widths[0]);
            max_corner.y_i = static_cast<size_t>((pair.second.y - mins[1]) / widths[1]);
    

            //results_list[n++] = range_query(data,code,pgm_idx, min_corner, max_corner);
            auto results = range_query(data,code,pgm_idx, min_corner, max_corner);
            results_list[n++] = results.size();
        }
        auto query_time = std::chrono::duration_cast<std::chrono::microseconds>(std::chrono::high_resolution_clock::now() - query_start);
        results_time[t++] = query_time.count();
    }
    for(int i=0;i<5;i++)
        std::cout << "查询时间: " << results_time[i]/1000 << " 毫秒" << std::endl;
    for (size_t i = 0; i < 50; ++i) {
        std::cout << "查询框 " << i + 1 << " 找到 " << results_list[i] << " 个点" << std::endl;
    }

}
        