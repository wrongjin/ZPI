#include <bits/stdc++.h>
#include <chrono>
#include <random>
using namespace std;
using namespace chrono;

// ==================== 数据结构 ====================
struct Point {
    double x, y;
    Point() = default;
    Point(double x_, double y_) : x(x_), y(y_) {}
};

// ==================== 工具函数 ====================
vector<Point> read_data_from_csv(const string& filename) {
    vector<Point> data;
    ifstream file(filename);
    string line;
    while (getline(file, line)) {
        if (line.empty()) continue;
        stringstream ss(line);
        string v1, v2;
        if (!getline(ss, v1, ',')) continue;
        if (!getline(ss, v2, ',')) continue;
        try {
            double x = stod(v1), y = stod(v2);
            data.emplace_back(x, y);
        } catch (...) { continue; }
    }
    return data;
}

// ==================== SPRIGIndex (按论文实现) ====================
class SPRIGIndex {
public:
    struct CellInfo {
        size_t offset;
        size_t size;
    };

    SPRIGIndex(int n_cols, int n_rows) : n(n_cols), m(n_rows), egx(0), egy(0) {}

    void build(const vector<Point>& points);
    void trainErrorGuarantee(const vector<Point>& workload);
    vector<Point> rangeQuery(double bx, double by, double tx, double ty) const;

    // 公开成员（用于分析）
    vector<double> Bx, By;
    vector<Point> data;
    vector<CellInfo> table;
    int egx, egy;

private:
    int n, m;

    static vector<double> buildBoundary(const vector<double>& coords, int num_cells);
    int computeCellId(double x, double y) const;
    double predictCellIdContinuous(double x, double y) const;
    int predictCellId(double x, double y) const;
    int getRealCellId(double x, double y) const;
    int locateIndex(const vector<double>& B, double v) const;
};

// ==================== 核心实现 ====================

// Algorithm 2: Build Boundary (按论文)
vector<double> SPRIGIndex::buildBoundary(const vector<double>& coords, int num_cells) {
    if (num_cells <= 0) return {};
    int N = coords.size();
    if (N == 0) return {};

    vector<double> sorted = coords;
    sort(sorted.begin(), sorted.end());

    double xmin = sorted.front();
    double xmax = sorted.back();
    if (xmin == xmax) {
        vector<double> B(num_cells + 1, xmin);
        return B;
    }

    vector<double> B;
    B.reserve(num_cells + 1);
    B.push_back(xmin);

    // 论文 Algorithm 2: cumulative count >= k * (N / num_cells)
    for (int k = 1; k < num_cells; ++k) {
        double target_rank = k * static_cast<double>(N) / num_cells;
        int idx = min(static_cast<int>(floor(target_rank)), N - 1);
        B.push_back(sorted[idx]);
    }
    B.push_back(xmax);

    // 去重（防止重复值导致边界相同）
    sort(B.begin(), B.end());
    B.erase(unique(B.begin(), B.end()), B.end());

    // 如果去重后不足，用线性插值补齐（极端情况）
    while ((int)B.size() < num_cells + 1) {
        vector<double> newB;
        newB.push_back(xmin);
        for (int i = 1; i < num_cells; ++i) {
            double t = static_cast<double>(i) / num_cells;
            newB.push_back(xmin + t * (xmax - xmin));
        }
        newB.push_back(xmax);
        B = move(newB);
        break;
    }

    // 确保长度
    if ((int)B.size() > num_cells + 1) {
        B.resize(num_cells + 1);
    }
    return B;
}

void SPRIGIndex::build(const vector<Point>& points) {
    if (points.empty()) return;

    // 1. 提取坐标
    vector<double> xs, ys;
    xs.reserve(points.size());
    ys.reserve(points.size());
    for (const auto& p : points) {
        xs.push_back(p.x);
        ys.push_back(p.y);
    }

    // 2. 构建边界（Algorithm 2）
    Bx = buildBoundary(xs, n);
    By = buildBoundary(ys, m);

    // 3. 分配点到 cell 并排序
    struct Item { int cid; Point p; };
    vector<Item> items;
    items.reserve(points.size());
    for (const auto& p : points) {
        int cid = computeCellId(p.x, p.y);
        items.push_back({cid, p});
    }

    sort(items.begin(), items.end(), [](const Item& a, const Item& b) {
        return a.cid < b.cid;
    });

    // 4. 构建 data 和 table
    data.clear();
    data.reserve(points.size());
    table.assign(n * m, {0, 0});

    if (items.empty()) return;

    int cur_cid = items[0].cid;
    size_t start = 0;
    for (size_t i = 0; i < items.size(); ++i) {
        if (items[i].cid != cur_cid) {
            table[cur_cid] = {start, i - start};
            cur_cid = items[i].cid;
            start = i;
        }
        data.push_back(items[i].p);
    }
    table[cur_cid] = {start, items.size() - start};

    egx = egy = 0; // 初始为0，由train设置
}

int SPRIGIndex::locateIndex(const vector<double>& B, double v) const {
    if (v <= B[0]) return 0;
    if (v >= B.back()) return (int)B.size() - 2;
    auto it = upper_bound(B.begin(), B.end(), v);
    int idx = (int)(it - B.begin()) - 1;
    return max(0, min(idx, (int)B.size() - 2));
}

int SPRIGIndex::computeCellId(double x, double y) const {
    int ix = locateIndex(Bx, x);
    int iy = locateIndex(By, y);
    return iy * n + ix;
}

double SPRIGIndex::predictCellIdContinuous(double x, double y) const {
    int ix = locateIndex(Bx, x);
    int iy = locateIndex(By, y);

    double x0 = Bx[ix], x1 = Bx[ix+1];
    double y0 = By[iy], y1 = By[iy+1];

    double tx = (x1 == x0) ? 0.0 : (x - x0) / (x1 - x0);
    double ty = (y1 == y0) ? 0.0 : (y - y0) / (y1 - y0);

    double c00 = iy * n + ix;
    double c10 = iy * n + (ix + 1);
    double c01 = (iy + 1) * n + ix;
    double c11 = (iy + 1) * n + (ix + 1);

    double c0 = c00 * (1 - tx) + c10 * tx;
    double c1 = c01 * (1 - tx) + c11 * tx;
    return c0 * (1 - ty) + c1 * ty;
}

int SPRIGIndex::predictCellId(double x, double y) const {
    double c = predictCellIdContinuous(x, y);
    int cid = (int)round(c);
    return max(0, min(cid, n * m - 1));
}

// Algorithm 1: Get Real Cell ID with Error Guarantee
int SPRIGIndex::getRealCellId(double x, double y) const {
    int pid = predictCellId(x, y);
    int lpx = pid % n;
    int lpy = pid / n;

    // Search in [lpx - egx, lpx + egx]
    int realX = -1;
    int leftX = max(0, lpx - egx);
    int rightX = min(n - 1, lpx + egx);
    for (int i = leftX; i <= rightX; ++i) {
        if (x >= Bx[i] && x <= Bx[i+1]) {
            realX = i;
            break;
        }
    }
    if (realX == -1) realX = locateIndex(Bx, x);

    int realY = -1;
    int leftY = max(0, lpy - egy);
    int rightY = min(m - 1, lpy + egy);
    for (int j = leftY; j <= rightY; ++j) {
        if (y >= By[j] && y <= By[j+1]) {
            realY = j;
            break;
        }
    }
    if (realY == -1) realY = locateIndex(By, y);

    return realY * n + realX;
}

void SPRIGIndex::trainErrorGuarantee(const vector<Point>& workload) {
    int maxEx = 0, maxEy = 0;
    for (const auto& q : workload) {
        int pred_cid = predictCellId(q.x, q.y);
        int pred_x = pred_cid % n;
        int pred_y = pred_cid / n;

        int true_x = locateIndex(Bx, q.x);
        int true_y = locateIndex(By, q.y);

        maxEx = max(maxEx, abs(pred_x - true_x));
        maxEy = max(maxEy, abs(pred_y - true_y));
    }
    egx = maxEx + 1; // 论文 Eq.(1): add 1 for safety
    egy = maxEy + 1;
}

vector<Point> SPRIGIndex::rangeQuery(double bx, double by, double tx, double ty) const {
    // 直接使用 locateIndex 精确定位查询窗口覆盖的 cells（更高效且准确）
    int x_left   = locateIndex(Bx, bx);
    int x_right  = locateIndex(Bx, tx);
    int y_bottom = locateIndex(By, by);
    int y_top    = locateIndex(By, ty);

    // Clamp to valid range
    x_left   = max(0, x_left);
    x_right  = min(n - 1, x_right);
    y_bottom = max(0, y_bottom);
    y_top    = min(m - 1, y_top);

    vector<Point> result;
    for (int iy = y_bottom; iy <= y_top; ++iy) {
        for (int ix = x_left; ix <= x_right; ++ix) {
            int cid = iy * n + ix;
            const auto& info = table[cid];
            if (info.size == 0) continue;

            // 快速判断 cell 是否完全包含于查询窗口
            bool fully_contained =
                (Bx[ix] >= bx) && (Bx[ix+1] <= tx) &&
                (By[iy] >= by) && (By[iy+1] <= ty);

            if (fully_contained) {
                // 批量插入（高效）
                result.insert(result.end(),
                              data.begin() + info.offset,
                              data.begin() + info.offset + info.size);
            } else {
                // 部分重叠：逐点检查
                for (size_t k = 0; k < info.size; ++k) {
                    const Point& p = data[info.offset + k];
                    if (p.x >= bx && p.x <= tx && p.y >= by && p.y <= ty) {
                        result.push_back(p);
                    }
                }
            }
        }
    }
    return result;
}

// ==================== 辅助：生成查询 ====================
vector<Point> sample_points(const vector<Point>& pts, size_t s, unsigned seed = 42) {
    mt19937 gen(seed);
    uniform_int_distribution<size_t> dist(0, pts.size() - 1);
    vector<Point> samples;
    samples.reserve(s);
    for (size_t i = 0; i < s; ++i) {
        samples.push_back(pts[dist(gen)]);
    }
    return samples;
}

pair<Point, Point> compute_min_max(const vector<Point>& pts) {
    Point mins{numeric_limits<double>::max(), numeric_limits<double>::max()};
    Point maxs{numeric_limits<double>::lowest(), numeric_limits<double>::lowest()};
    for (const auto& p : pts) {
        mins.x = min(mins.x, p.x); mins.y = min(mins.y, p.y);
        maxs.x = max(maxs.x, p.x); maxs.y = max(maxs.y, p.y);
    }
    return {mins, maxs};
}

vector<vector<pair<Point, Point>>> generate_range_queries(
    const vector<Point>& points, size_t s = 1000) 
{
    const double sel[5] = {0.001, 0.01, 0.05, 0.1, 0.2};
    auto samples = sample_points(points, s);
    auto [global_min, global_max] = compute_min_max(points);

    vector<vector<pair<Point, Point>>> groups;
    groups.reserve(5);

    for (int i = 0; i < 5; ++i) {
        vector<pair<Point, Point>> group;
        group.reserve(s);
        double step_x = (global_max.x - global_min.x) * sqrt(sel[i]);
        double step_y = (global_max.y - global_min.y) * sqrt(sel[i]);

        for (const auto& p : samples) {
            Point bl = p;
            Point tr{
                min(p.x + step_x, global_max.x),
                min(p.y + step_y, global_max.y)
            };
            group.emplace_back(bl, tr);
        }
        groups.push_back(move(group));
    }
    return groups;
}


void analyze_memory_usage(const SPRIGIndex& index) {
    cout << "\n=== SPRIG索引内存占用分析 ===\n";

    size_t data_mem     = index.data.capacity() * sizeof(Point);          // ≈ N*16
    size_t bx_mem       = index.Bx.capacity() * sizeof(double);           // (n+1)*8
    size_t by_mem       = index.By.capacity() * sizeof(double);           // (m+1)*8
    size_t table_mem    = index.table.capacity() * sizeof(SPRIGIndex::CellInfo); // n*m*16

    size_t total_index_size = data_mem + bx_mem + by_mem + table_mem;

   
    cout << "  - 总索引大小:           " << total_index_size  << " B\n";
}

// ==================== 主函数 ====================
int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    cout << "Loading data...\n";
    auto points = read_data_from_csv("/home/wrj/project/ZM/data/geonames6.csv");
    if (points.empty()) {
        cerr << "No data loaded!\n";
        return 1;
    }

    cout << "Building SPRIG index (n=m=764)...\n";
    SPRIGIndex index(764, 764);

    auto t0 = high_resolution_clock::now();
    index.build(points);
    auto t1 = high_resolution_clock::now();
    cout << "Build time: "
         << duration_cast<milliseconds>(t1 - t0).count() << " ms\n";

    // Train error guarantee on sampled workload (NOT full data!)
    cout << "Training error guarantee...\n";
    auto train_workload = sample_points(points, 1000);
    index.trainErrorGuarantee(train_workload);
    cout << "egx = " << index.egx << ", egy = " << index.egy << "\n";
    analyze_memory_usage(index);
    // Generate queries
    cout << "Generating queries...\n";
    auto query_groups = generate_range_queries(points, 1000);

    // Run queries
    vector<long long> times(5);
    vector<int> first_50_results;

    for (int g = 0; g < 5; ++g) {
        auto t_start = high_resolution_clock::now();
        for (size_t i = 0; i < query_groups[g].size(); ++i) {
            auto& [bl, tr] = query_groups[g][i];
            auto res = index.rangeQuery(bl.x, bl.y, tr.x, tr.y);
            if (first_50_results.size() < 50) {
                first_50_results.push_back(res.size());
            }
        }
        auto t_end = high_resolution_clock::now();
        times[g] = duration_cast<microseconds>(t_end - t_start).count();
    }

    // Output
    for (int i = 0; i < 5; ++i) {
        cout << "Group " << i+1 << " avg time: " << (times[i] / 1000) << " ms\n";
    }
    for (int i = 0; i < 50; ++i) {
        cout << "Query " << i+1 << ": " << first_50_results[i] << " points\n";
    }

    return 0;
}